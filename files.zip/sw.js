var V="life-quest-v1",FILES=["./","index.html","manifest.webmanifest","icon-192.png","icon-512.png"];
self.addEventListener("install",function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(FILES);}).then(function(){return self.skipWaiting();}));});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==V;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
function put(req,res){if(res&&(res.ok||res.type==="opaque")){var cp=res.clone();caches.open(V).then(function(c){c.put(req,cp);});}return res;}
self.addEventListener("fetch",function(e){
  var req=e.request;if(req.method!=="GET")return;
  if(req.mode==="navigate"){
    e.respondWith(fetch(req).then(function(r){return put(req,r);}).catch(function(){return caches.match(req).then(function(h){return h||caches.match(new URL("index.html",self.registration.scope));});}));
    return;
  }
  e.respondWith(caches.match(req).then(function(hit){
    var net=fetch(req).then(function(r){return put(req,r);}).catch(function(){return hit;});
    return hit||net;
  }));
});
